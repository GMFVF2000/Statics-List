//
// Created by abou on 24/09/2019.
//

#ifndef AMINATE_UTILS_H

#include <iostream>
#include <cstdlib>
#include <glutWindow.h>


#define AMINATE_UTILS_H


class Utils: public GlutWindow {
public:
    int value[20];
public:
    Utils(const string &title, int argc, char **argv, int width, int height): GlutWindow(argc, argv, title, width, height) {};

    void onStart() override;
    void onDraw() override;
    void onQuit() override;
    void onMouseMove(double cx,double cy) override;
    void onMouseDown(int button,double cx,double cy) override;
};

#endif //AMINATE_UTILS_H
