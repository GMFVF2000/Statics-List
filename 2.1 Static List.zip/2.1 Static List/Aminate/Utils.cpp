//
// Created by abou on 24/09/2019.
//

#include "Utils.h"
//
// Created by abou on 23/09/2019.
//

void Utils::onStart() {

    for (int i = 0; i < 20; ++i) {
        Utils::value[i]=std::rand()%99+1;
    }



}

void Utils::onQuit() {
    cout << "The end."  << endl;
}

void Utils::onDraw() {


}






void Utils::onMouseMove(double cx,double cy) {
  }

void Utils::onMouseDown(int button, double cx, double cy) {

}
