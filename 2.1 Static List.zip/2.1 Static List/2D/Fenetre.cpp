//
// Created by abou on 23/09/2019.
//

#include "Fenetre.h"
#include "Tab1D.h"
Tab1D *test= new Tab1D();
float pasH=float(1)/float(Tab1D::ny);
float pasV=float(1)/float(Tab1D::nx);
float posX=0;
float posY=0;
void Fenetre::onStart() {
    cout << "Start..."  << endl;
    glClearColor(1,1,1,1.0);
/*
    glPushMatrix();
    for (int i=0;i<Tab1D::ny;++i){
        for (int j = 0; j < Tab1D::nx; ++j) {
            glColor3f(1.0,1.0,1.0);
          //  box(0,0, float(1)/float(Tab1D::ny), float(1)/float(Tab1D::nx));
            rect(0.05, 0.05, 0.25, 0.9);
          posX+=pasH;

        }
        posX=0.0;
        posY+=pasV;

    }



    glPopMatrix();


*/




}

void Fenetre::onQuit() {
    cout << "The end."  << endl;
}

void Fenetre::onDraw() {



    glPushMatrix();

    for (int i=0; i<20; i++) {
        glColor3f(0.0f,0.0f,0.0f);
        box(10, 10, 40, 80);
        glColor3f(1.0f,1.0f,1.0f);
        box(10, 90, 40, 40);
        rect(10, 10, 40, 40);
        rect(10, 50, 40, 40);


        glColor3f(0.0f,0.0f,0.0f);
        rect(10, 90, 40, 40);
        drawText(30,100,to_string(i),ALIGN_CENTER);

        glTranslated(40,0.0,0.0);
    }


    //glColor3f(0.0,0.0,0.0);
    //box(posX, posY, float(1)/float(Tab1D::ny),float(1)/float(Tab1D::nx) );
// Function called in loop


/*

    for (int i=0;i<Tab1D::ny;++i){
        for (int j = 0; j < Tab1D::nx; ++j) {

            glColor3f(0.0,0.0,0.0);
            box(posX, posY, float(1)/float(Tab1D::ny),float(1)/float(Tab1D::nx) );

            posX+=float(1)/float(Tab1D::nx);
        }
        posX=0.0;
        posY+=pasV;

    }

*/
    glPopMatrix();

 }






void Fenetre::onMouseMove(double cx,double cy) {
    isOverBox1 = isInRect(cx,cy,0.05,0.05,0.25,0.9);
    isOverBox2 = isInRect(cx,cy,0.7,0.05,0.25,0.9);
}

void Fenetre::onMouseDown(int button, double cx, double cy) {
    if (isOverBox1) {
        value--;
    } else if (isOverBox2) {
        value++;
    }

}
