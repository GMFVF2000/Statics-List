#include <iostream>
#include <cstdlib>
#include "Fenetre.h"
#include "Tab1D.h"
using namespace std;





int main(int argc,char **argv) {


    Fenetre ex("Rectangles", argc,argv,800,800);
    ex.start();
    //cout << float(1)/float(14)<<endl;

    return 0;

}

