//
// Created by abou on 23/09/2019.
//

#include "Tab1D.h"

void getValue(int i);

int Tab1D::getColumns(int index) {
    return index%Tab1D::nx;
}

int Tab1D::getLine(int index) {
    return index/Tab1D::nx;
}

int Tab1D::getValue(int l, int c) {
    return tabLin.at(l*Tab1D::nx+c);
}
int Tab1D::getValue(int index) {
    return tabLin.at(index);
}

void Tab1D::fill2DTab(array <array<uint8_t,16>,14 > tab){
            for(int i=0;i<Tab1D::nx;++i){
                for (int j = 0; j <Tab1D::ny ; ++j) {
                    tab[i][j]=getValue(i);

                }

            }

}
void Tab1D::fill2DTabOnLoop(array <array<uint8_t,16>,14 > tab) {
    for (int i = 0; i < Tab1D::nx * Tab1D::ny; ++i) {
        tab[Tab1D::getLine(i)][Tab1D::getColumns(i)] = getValue(i);
    };


}