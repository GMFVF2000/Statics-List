//
// Created by abou on 23/09/2019.
//
#include <iostream>
#include <cstdlib>
#include <glutWindow.h>

using namespace std;

#ifndef INC_2D_FENETRE_H
#define INC_2D_FENETRE_H



class Fenetre: public GlutWindow {
    int value=10;
    bool isOverBox1,isOverBox2;
public:
    Fenetre(const string &title,int argc,char **argv,int width,int height):GlutWindow(argc,argv,title,width,height) {};

    void onStart() override;
    void onDraw() override;
    void onQuit() override;
    void onMouseMove(double cx,double cy) override;
    void onMouseDown(int button,double cx,double cy) override;
};

#endif //INC_2D_FENETRE_H
